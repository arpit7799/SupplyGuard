import React, { useState, useEffect, useMemo } from 'react';
import RiskAlertBanner from './components/RiskAlertBanner';
import DashboardHeader from './components/DashboardHeader';
import RiskHeatmap from './components/RiskHeatmap';
import RiskTrend from './components/RiskTrend';
import AlertCard from './components/AlertCard';

// Mock Data - In a real scenario, this comes from your ML pipeline
const MOCK_HEADLINES = [
  { id: 1, title: 'Port Congestion at Shanghai Terminals', country: 'China', category: 'transport', risk: 'high', time: '14m ago' },
  { id: 2, title: 'Extreme Weather Warning: North Sea', country: 'Germany', category: 'weather', risk: 'medium', time: '1h ago' },
  { id: 3, title: 'Semiconductor Lead Times Stabilizing', country: 'Taiwan', category: 'transport', risk: 'low', time: '3h ago' },
];

const App = () => {
  const [headlines, setHeadlines] = useState(MOCK_HEADLINES);
  const [searchTerm, setSearchTerm] = useState('');
  const [refreshTimer, setRefreshTimer] = useState(30);
  const [showAlert, setShowAlert] = useState(true);

  // 1. Filter Logic (Search Feature)
  const filteredHeadlines = useMemo(() => {
    return headlines.filter(h => 
      h.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      h.country.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }, [searchTerm, headlines]);

  // 2. Auto-Refresh Logic (30s Feature)
  useEffect(() => {
    const timer = setInterval(() => {
      setRefreshTimer((prev) => {
        if (prev <= 1) {
          console.log("Fetching fresh intelligence..."); // Trigger API call
          return 30;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const handleExport = () => {
    window.print();
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans selection:bg-blue-500/30">
      {/* High-Risk Spike Alerts Banner */}
      {showAlert && (
        <RiskAlertBanner 
          alerts={[{ location: 'Suez Canal', value: 92 }]} 
          onClose={() => setShowAlert(false)} 
        />
      )}

      {/* Dashboard Header with Search & Export */}
      <DashboardHeader 
        onSearch={setSearchTerm} 
        onExport={handleExport}
        refreshTimer={refreshTimer}
      />

      <main className="max-w-[1600px] mx-auto p-6 grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Column: Intelligence Feed (4 Cols) */}
        <section className="lg:col-span-4 space-y-4 order-2 lg:order-1">
          <div className="flex justify-between items-center mb-2 px-2">
            <h2 className="text-xs font-black uppercase tracking-widest text-slate-500">Live Intel Feed</h2>
            <span className="text-[10px] bg-slate-800 px-2 py-0.5 rounded text-slate-400">
              {filteredHeadlines.length} Events
            </span>
          </div>
          <div className="space-y-3 overflow-y-auto max-h-[calc(100vh-250px)] pr-2 custom-scrollbar">
            {filteredHeadlines.map(item => (
              <AlertCard key={item.id} item={item} />
            ))}
          </div>
        </section>

        {/* Right Column: Visualization Suite (8 Cols) */}
        <section className="lg:col-span-8 space-y-6 order-1 lg:order-2">
          {/* Risk Heatmap World Map */}
          <div className="glass rounded-3xl overflow-hidden border border-slate-800 shadow-2xl">
            <RiskHeatmap data={[{ lat: 31.2, lng: 121.4, weight: 0.8 }, { lat: 30.0, lng: 32.5, weight: 0.9 }]} />
          </div>

          {/* 7-Day Risk Trend Chart */}
          <div className="glass rounded-3xl p-6 border border-slate-800">
            <RiskTrend data={[
              { name: 'Mon', risk: 40 }, { name: 'Tue', risk: 35 }, 
              { name: 'Wed', risk: 75 }, { name: 'Thu', risk: 90 }, 
              { name: 'Fri', risk: 60 }, { name: 'Sat', risk: 55 }, { name: 'Sun', risk: 80 }
            ]} />
          </div>
        </section>

      </main>

      {/* Subtle Footer */}
      <footer className="p-8 text-center no-print">
        <p className="text-[10px] text-slate-600 font-mono tracking-widest uppercase">
          Supply Chain Risk Architecture • Arpit Pandey • Built 2026
        </p>
      </footer>
    </div>
  );
};

export default App;